﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFDataGrid
{
    /// <summary>
    /// Interaction logic for Customers.xaml
    /// </summary>
    public partial class Customers : UserControl
    {

        BTKassaDataContext db = new BTKassaDataContext();

        public Customers()
        {
            InitializeComponent();
            SetData();

            dgKlanten.ItemsSource = db.customers.ToList();

        }

        private void SetData()
        {
            //cbCustomer.ItemsSource = db.customers.ToList();
            //cbCustomer.DisplayMemberPath = "firstname";
            //dgKlanten.ItemsSource = db.itemsinorders.ToList();


        }


       



        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BTKassaDataContext dataContext = new BTKassaDataContext();
                customer customerRow = dgKlanten.SelectedItem as customer;
                int customerID = customerRow.id;
                int m = customerID;
                customer customer = (from p in dataContext.customers
                                     where p.id == customerID
                                     select p).Single();
                customer.firstname = customerRow.firstname;
                customer.lastname = customerRow.lastname;
                customer.email = customerRow.email;
                customer.city = customerRow.city;
                customer.phonenumber = customerRow.phonenumber;
                dataContext.SubmitChanges();
                MessageBox.Show("Row Updated Successfully.");
               
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
                return;
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            BTKassaDataContext cd = new BTKassaDataContext();
            customer customerRow = dgKlanten.SelectedItem as customer;
            var customer = (from p in cd.customers
                            where p.id == customerRow.id
                            select p).Single();
            cd.customers.DeleteOnSubmit(customer);
            cd.SubmitChanges();
            MessageBox.Show("Row Deleted Successfully.");
        }

        private void btnOpslaan_Click(object sender, RoutedEventArgs e)
        {
            //Connectie naar je DB
            customer c = new customer();
            c.firstname = txtFname.Text;
            c.lastname = txtLname.Text;
            c.city = txtCity.Text;
            c.phonenumber = txtPhone.Text;
            c.email = txtEmail.Text;


            //Zet Data in de wachtrij
            db.customers.InsertOnSubmit(c);
            //De sumbit die het daadwerkelijk opslaat
            db.SubmitChanges();

            dgKlanten.ItemsSource = db.customers.ToList();

        }
    }



}
