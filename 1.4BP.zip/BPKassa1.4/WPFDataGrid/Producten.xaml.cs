﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFDataGrid
{
    /// <summary>
    /// Interaction logic for Producten.xaml
    /// </summary>
    public partial class Producten : UserControl
    {
        BTKassaDataContext db = new BTKassaDataContext();

        public Producten()
        {
            InitializeComponent();
            SetData();
        }

        private void SetData()
        {
            dgProduct.ItemsSource = db.products.ToList();
            cbType.ItemsSource = db.producttypes.ToList();
            cbType.DisplayMemberPath = "type";
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (cbType.SelectedItem != null)
            {
                //Textbox uitlezen en opslaan in variable
                string sProductnaam = txtProductnaam.Text;
                //Combobox ui
                producttype myPT = (producttype)cbType.SelectedItem;
                //Nieuw product aanmaken
                product myProduct = new product();
                //Velden met variabele vullen
                myProduct.name = sProductnaam;
                myProduct.producttypeId = myPT.id;
                //Ready changes & changes uitvoeren
                db.products.InsertOnSubmit(myProduct);
                db.SubmitChanges();
                //Refresh database
                SetData();
                //Leegmaken en Confirmation
                txtProductnaam.Text = string.Empty;

                MessageBox.Show("Opgeslagen");
            }
            else
            {
                MessageBox.Show("Selecteer eerst een type");
            }
        }


        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BTKassaDataContext dataContexten = new BTKassaDataContext();
                product productRow = dgProduct.SelectedItem as product;
                int productID = productRow.id;
                int m = productID;
                product product = (from p in dataContexten.products
                                     where p.id == productID
                                     select p).Single();
                product.name = productRow.name;
                product.producttype = productRow.producttype;
                product.prijs = productRow.prijs;
                dataContexten.SubmitChanges();
                MessageBox.Show("Row Updated Successfully.");

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
                return;
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            BTKassaDataContext ps = new BTKassaDataContext();
            product productRow = dgProduct.SelectedItem as product;
            var product = (from p in ps.products
                            where p.id == productRow.id
                            select p).Single();
            ps.products.DeleteOnSubmit(product);
            ps.SubmitChanges();
            SetData();
            MessageBox.Show("Row Deleted Successfully.");
        }

       
    }
}
