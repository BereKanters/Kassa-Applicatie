﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Windows.Controls;
using System.Diagnostics;
using System.Globalization;

namespace WPFDataGrid
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        BTKassaDataContext db = new BTKassaDataContext();
        public Window1()
        {
            InitializeComponent();
        }
     
       
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
        }
        
        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {            
                LoadCustomers();                        
        }

        private void LoadCustomers()
        {
            
            BTKassaDataContext cd = new BTKassaDataContext();
            var customers = (from p in cd.customers
                             select p).Take(10);
            MyDataGrid.ItemsSource = customers;
            LoadButton.Content = "Customers Loaded";
        }
       
        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BTKassaDataContext dataContext = new BTKassaDataContext();
                customer customerRow = MyDataGrid.SelectedItem as customer;
                int customerID = customerRow.id;
                int m = customerID;
                customer customer = (from p in dataContext.customers
                                     where p.id == customerID
                                     select p).Single();
                customer.firstname = customerRow.firstname;
                customer.lastname = customerRow.lastname;
                customer.email = customerRow.email;
                customer.city = customerRow.city;
                customer.phonenumber = customerRow.phonenumber;
                dataContext.SubmitChanges();
                MessageBox.Show("Row Updated Successfully.");
                LoadCustomers();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
                return;
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {           
            BTKassaDataContext cd = new BTKassaDataContext();
            customer customerRow = MyDataGrid.SelectedItem as customer;
            var customer = (from p in cd.customers
                            where p.id == customerRow.id
                            select p).Single();
            cd.customers.DeleteOnSubmit(customer);
            cd.SubmitChanges();
            MessageBox.Show("Row Deleted Successfully.");
            LoadCustomers();
        }

        private void btnToevoegen_Click(object sender, RoutedEventArgs e)
        {
            Add toevoegen = new Add();
            toevoegen.Show();
            this.Close();
        }

        private void btnBestelling_Click(object sender, RoutedEventArgs e)
        {
            Bestelling order = new Bestelling();
            order.Show();
            this.Close();

        }
    }
}
