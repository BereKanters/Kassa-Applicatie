﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFDataGrid
{
    /// <summary>
    /// Interaction logic for Add.xaml
    /// </summary>
    public partial class Add : Window
    {

        public Add()
        {
            InitializeComponent();
        }


        private void btnToevoegen_Click(object sender, RoutedEventArgs e)
        {
            grLoader.Children.Clear();
            grLoader.Children.Add(new Customers());
        }

        private void btnBestelling_Click(object sender, RoutedEventArgs e)
        {
            grLoader.Children.Clear();
            grLoader.Children.Add(new Producten());
        }

        private void btnReturn_Click(object sender, RoutedEventArgs e)
        {
            Window1 w1 = new Window1();
            w1.Show();
            this.Close();
        }
    }
}
